const express = require("express");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const pending = new Map();

// Resolve a Roblox username and read the public profile description.
// This only proves control if the exact one-time code is visible in the bio.
app.post("/api/start", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    if (!username || username.length > 20) {
      return res.status(400).json({ error: "Digite um nome de usuário Roblox válido." });
    }

    const lookup = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: false })
    });
    if (!lookup.ok) throw new Error("Não foi possível consultar o Roblox agora.");
    const lookupData = await lookup.json();
    const user = lookupData.data && lookupData.data[0];
    if (!user) return res.status(404).json({ error: "Não encontramos essa conta Roblox." });

    const code = "EBL-" + crypto.randomBytes(3).toString("hex").toUpperCase();
    pending.set(code, { userId: user.id, username: user.name, createdAt: Date.now() });

    res.json({ code, username: user.name, userId: user.id });
  } catch (err) {
    res.status(502).json({ error: err.message || "Erro ao consultar o Roblox." });
  }
});

app.post("/api/verify", async (req, res) => {
  try {
    const code = String(req.body.code || "").trim().toUpperCase();
    const record = pending.get(code);
    if (!record) return res.status(404).json({ error: "Código não encontrado ou já utilizado. Gere outro código." });
    if (Date.now() - record.createdAt > 15 * 60 * 1000) {
      pending.delete(code);
      return res.status(410).json({ error: "Código expirado. Gere outro código." });
    }

    const profileResponse = await fetch(`https://users.roblox.com/v1/users/${record.userId}`);
    if (!profileResponse.ok) throw new Error("Não foi possível consultar a bio desse perfil.");
    const profile = await profileResponse.json();
    const description = String(profile.description || "");

    if (!description.includes(code)) {
      return res.status(200).json({
        verified: false,
        message: "Ainda não encontramos o código na bio. Confira se salvou as alterações no Roblox."
      });
    }

    pending.delete(code);
    // Prototype only: this response does not grant a Discord role or persist a Discord link.
    res.json({
      verified: true,
      username: record.username,
      userId: record.userId,
      message: "Bio confirmada! A conta Roblox foi validada."
    });
  } catch (err) {
    res.status(502).json({ error: err.message || "Falha ao verificar a bio." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`EB DO LITERAL ativo na porta ${PORT}`));
