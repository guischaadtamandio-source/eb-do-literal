const startForm = document.getElementById("startForm");
const startBtn = document.getElementById("startBtn");
const verifyBtn = document.getElementById("verifyBtn");
const codeArea = document.getElementById("codeArea");
const codeEl = document.getElementById("code");
const message = document.getElementById("message");
let currentCode = "";

function showMessage(text, isError=false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

startForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  startBtn.disabled = true;
  showMessage("Consultando o Roblox...");
  try {
    const response = await fetch("/api/start", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({username: document.getElementById("username").value})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Não foi possível gerar o código.");
    currentCode = data.code;
    codeEl.textContent = currentCode;
    codeArea.classList.remove("hidden");
    showMessage(`Conta encontrada: ${data.username} (ID ${data.userId}).`);
  } catch (error) {
    showMessage(error.message, true);
  } finally {
    startBtn.disabled = false;
  }
});

document.getElementById("copyBtn").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(currentCode); showMessage("Código copiado!"); }
  catch { showMessage("Não foi possível copiar automaticamente. Selecione o código e copie.", true); }
});

verifyBtn.addEventListener("click", async () => {
  if (!currentCode) return;
  verifyBtn.disabled = true;
  showMessage("Verificando a descrição pública do perfil...");
  try {
    const response = await fetch("/api/verify", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({code: currentCode})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Falha na verificação.");
    if (data.verified) {
      showMessage(`Bio confirmada para ${data.username}! Esta demonstração ainda não concede cargo no Discord.`);
      codeArea.classList.add("hidden");
    } else {
      showMessage(data.message, true);
    }
  } catch (error) {
    showMessage(error.message, true);
  } finally {
    verifyBtn.disabled = false;
  }
});
